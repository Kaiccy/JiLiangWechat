
var config = require('../config');
var util = require('MD5.js') ;
var apiUrl = config.ajaxUrl;
let ajaxJson = {
  ajaxPoint : '',
  params:{},
  header: {
    'content-type': 'application/json',
    // 'content-type': 'multipart/form-data'
  },
  complete:function(res) {

  },
  success:function(res){
    
  },
  fail:function(res) {

  }
}
function getMd5(data) {

  let newKey = Object.keys(data).sort(); // 将参数data的键进行排序
  let newObj = {};
  for(const i in newKey){
    newObj[newKey[i]] = data[newKey[i]]; // 根据newKey[i]的值找到data对应的值，然后插入到newObj中
  }

  let sign = '';
  for(const i in newObj){
    sign += newObj[i];
  }
  
  // var sign = str + 'yztx';
  // let md5 = crypto.createHash("md5");
  // md5.update(sign);  //这是要加密的字符串
  // sign = md5.digest('hex'); // 加密
  sign = util.hexMD5(encodeURIComponent(sign) + 'yztx'); //给sign中的参数编码
  return sign
}

function GET(ajaxJson) {
  request('GET', ajaxJson)
}
function POST(ajaxJson) {
  request('POST', ajaxJson)
}
function request(method,ajaxJson) {
  const params = ajaxJson.params; //参数
  params.fromto = '1';
  // console.log(ajaxJson)

  // 判断是否登录，如果登录过了后面所有的请求加入token参数
  if (wx.getStorageSync('wxInfo')){
    params.token = wx.getStorageSync('wxInfo').token;
  }
  
  const sign = getMd5(params);
  var jsonSign = ''
  for(var i in params){
    jsonSign += i+'='+params[i]+'&'
  }
  var header = ajaxJson.header;
  var ajaxUrl = apiUrl + ajaxJson.ajaxPoint + '?' + jsonSign + 'sign=' + sign;
  
  if(method=='POST'){
    header = {
      "Content-Type": "application/x-www-form-urlencoded"
    };
    ajaxUrl = ajaxJson.ajaxPoint + '?sign=' + sign
  }
  
  wx.request({
    url: ajaxUrl,
    data: params,
    method: method,
    header: header,
    success: function (res) {
      ajaxJson.success(res)
      //每次完成通信,记录时间戳
      // if (res.data.error == '100003'){
      //   wx.reLaunch({
      //     url: '/pages/login/grant/grant'
      //   })
      // }
    },
    fail: function () {
      if(ajaxJson.fail){
        ajaxJson.fail()
      }else{
        wx.showToast({
          title: 'Request error',
          icon: 'none'
        })
      }    
    },
    complete: function () {
      if(ajaxJson.complete){
        ajaxJson.complete()
      }

    }
  })
}

module.exports = {
  GET,
  POST
}
