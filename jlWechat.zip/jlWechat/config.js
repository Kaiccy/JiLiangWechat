

var config = {

  // 接口地址
  ajaxUrl: 'https://international.cjlu.edu.cn/sms/webservise/',
  imgUrl: 'https://international.cjlu.edu.cn/upload/',
  fileUrl: 'https://international.cjlu.edu.cn/upload/docs/',
  webUrl: 'https://international.cjlu.edu.cn/sms/other/'

// 测试接口 192.168.0.169:8080
  // ajaxUrl: 'http://192.168.0.169:8080/jlisms/webservise/',
  // imgUrl: 'http://192.168.0.169:8080/upload/',
  // fileUrl: 'http://192.168.0.169:8080/upload/docs/',
  // webUrl: 'http://192.168.0.169:8080/jlisms/other/'
};

module.exports = config;