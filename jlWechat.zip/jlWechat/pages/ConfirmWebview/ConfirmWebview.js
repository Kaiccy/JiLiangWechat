// pages/ConfirmWebview/ConfirmWebview.js

const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    type:'', //1 学分，2 学籍,3 新闻详情
    url:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let id = options.id;
    let type = options.type;
    var path = '';
    if (type == 1){
      //学分
      path = config.webUrl + "weChatxf?id=" + id
    } else if (type == 2){
      //学籍
      path = config.webUrl + "weChatxj?id=" + id
    }else{
      let jsonParam = JSON.parse(decodeURIComponent(options.jsonParam));
      path = jsonParam.url
    }
    console.log('path=='+path);
    that.setData({
      url: path
    })
  },

})