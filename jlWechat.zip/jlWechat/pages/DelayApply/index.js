// pages/leaveApply/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo: [],
    visatype: ['The X1 long-term', 'X2 short - term', 'Visa X', 'Visa F', 'Visa L', 'Visa S', 'Other', 'Residence permit'],
    index: 0,
    bindChange1: '',
    bindChange2: '',
    bindChange3: '',
    bindChange4: '',
    bindChange5: '',
    bindChange6: '',

    multiArr: [[], []],
    multiIndex: [0, 0],
  },
  /* 毕业去向 */
  bindPickerChange: function (e) {
    let that = this;
    that.setData({
      index: Number(e.detail.value)
    })
  },
  bindChange1: function (e) {
    let that = this;
    that.setData({
      bindChange1: e.detail.value
    })
  },
  bindChange2: function (e) {
    let that = this;
    that.setData({
      bindChange2: e.detail.value
    })
  },
  bindChange3: function (e) {
    let that = this;
    that.setData({
      bindChange3: e.detail.value
    })
  },
  bindChange4: function (e) {
    let that = this;
    that.setData({
      bindChange4: e.detail.value
    })
  },
  bindChange5: function (e) {
    let that = this;
    that.setData({
      bindChange5: e.detail.value
    })
  },
  bindChange6: function (e) {
    let that = this;
    that.setData({
      bindChange6: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    // 获取学年学期
    that.getYearList();
  },
  
  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

  /*提交申请 */
  tj: function (e) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if (that.data.bindChange1 !== '' && that.data.bindChange2 !== '' && that.data.bindChange3 !== '' && that.data.bindChange4 !== '' && that.data.bindChange5 !== '' && that.data.bindChange6 !== '' && sterm !== '') {
      ajax.GET({
        ajaxPoint: '/saveVisaExtension',
        params: {
          xh: userInfo.xh,
          qzzl: that.data.index + 1,
          qzcgh: that.data.bindChange1,
          qzh: that.data.bindChange2,
          rjcs: that.data.bindChange3,
          tlts: that.data.bindChange4,
          qzblfs: that.data.bindChange5,
          qzfy: that.data.bindChange6,
          pxq: sterm
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Successful application',
              confirmText: 'Confirm',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: 'Please improve the application information',
        icon: 'none'
      })
    }
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})