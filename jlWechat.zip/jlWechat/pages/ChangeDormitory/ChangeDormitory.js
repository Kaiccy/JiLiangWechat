// pages/ChangeDormitory/ChangeDormitory.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // multiArr:[[],[],[]],
    // multiIndex: [],
    buildingArr:null, //楼
    floorArr:null, //楼层
    roomArr:null, //房间
    col: 0, //滚动第几列
    isScroll:false, //是否有滑动
    note:null, //原因
    userInfo: null, //用户信息
    dormitory:null, //宿舍号

    hiddenModalput: true, //隐藏弹出输入框
    stuId: '', //学号
    isDownloaded: false, //是否有下载文件
    attachment: '', //附件图片
    imagePath: '', //临时图片路径

    multiArr: [[], []],
    multiIndex: [0, 0],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    // this.getDormitoryList(0);
    this.getCurrentDormitory();
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    // 获取学年学期
    that.getYearList();
  },

  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

  // 获取寝室列表
  getDormitoryList: function (ssh) {
    let that = this;
    // console.log('pid = ' + ssh);
    ajax.GET({
      ajaxPoint: '/getDorm',
      params: {
        pid: ssh
      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infoList;
        if (res.data.retcode == 0) {
          if (!that.data.isScroll){
            //未滑动
            if(that.data.buildingArr == null){
              var bArr = [];
              for (var i = 0; i < arr.length; i++) {
                bArr.push(arr[i].ssfloor);
              }
              mArr[0] = bArr;
              that.setData({
                buildingArr: arr
              })
              that.getDormitoryList(arr[0].ssh);
            } else if (that.data.floorArr == null){
              var fArr = [];
              for (var i = 0; i < arr.length; i++) {
                fArr.push(arr[i].lc);
              }
              mArr[1] = fArr;
              that.setData({
                floorArr: arr
              })
              that.getDormitoryList(arr[0].ssh);
            } else if (that.data.roomArr == null) {
              var rArr = [];
              for (var i = 0; i < arr.length; i++) {
                rArr.push(arr[i].ssfjh);
              }
              mArr[2] = rArr;
              that.setData({
                roomArr: arr
              })
            }
          }else{
            //有滑动            
            switch (that.data.col + 1) {
              case 1:
                var fArr = [];
                for (var i = 0; i < arr.length; i++) {
                  fArr.push(arr[i].lc);
                }
                mArr[1] = fArr;
                that.setData({
                  floorArr: arr,
                  col:1
                })
                if(arr.length != 0){
                  let pid = arr[0].ssh;
                  that.getDormitoryList(pid);
                }
                break;
              case 2:
                var rArr = [];
                for (var i = 0; i < arr.length; i++) {
                  rArr.push(arr[i].ssfjh);
                }
                mArr[2] = rArr;
                that.setData({
                  roomArr: arr,
                  col: 2
                })
                break;
            }
          }
          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e){
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })    
    var pid = '';
    var mutA = that.data.multiArr;
    switch (e.detail.column) {
      case 0:
        let arr0 = that.data.buildingArr;
        for (var i = 0; i < arr0.length; i++) {
          if (e.detail.value == i){
            pid = arr0[i].ssh;
          }
        }        
        mutA[1] = [];
        mutA[2] = [];
        that.setData({
          floorArr: null,
          roomArr:null,
          multiArr: mutA
        })
        break;
      case 1:
        let arr1 = that.data.floorArr;
        for (var i = 0; i < arr1.length; i++) {
          if (e.detail.value == i) {
            pid = arr1[i].ssh;
          }
        }
        mutA[2] = [];
        that.setData({
          roomArr: null,
          multiArr: mutA
        })
        break;
    }
    that.setData({
      isScroll:true
    })
    that.getDormitoryList(pid);
  },

  //获取当前宿舍
  getCurrentDormitory: function(){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });
    ajax.GET({
      ajaxPoint: '/getStudentDorm',
      params: {
        xh: userInfo.xh
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            dormitory: res.data
          })
        } else {
          wx.showModal({
            title: 'Error',
            content: 'Failed to get current room!',
            cancelText: 'Cancel',
            confirmText: 'Confirm',
            success(res) {
              if (res.confirm) {
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
        }
      }
    })
  },

  //获取原因
  bindNoteChange: function (e){
    let that = this;
    let reason = e.detail.value;
    that.setData({
      note:reason
    })
  },

  // 附件部分

  //下载文件
  downloadFiles: function (e) {
    let that = this;
    that.setData({
      hiddenModalput: false
    })
  },

  //弹出框的取消按钮
  cancel: function () {
    let that = this;
    that.setData({
      hiddenModalput: true
    });
  },

  //弹出框的确认
  confirm: function () {
    let that = this;
    if (that.data.stuId == that.data.userInfo.number) {
      //下载
      let url = config.fileUrl + 'Application for Changing Room.doc';
      console.log(url);
      //文件 
      wx.showModal({
        title: "Form's link",
        content: url,
        cancelText: 'Cancel',
        confirmText: 'Copy',
        success(res) {
          if (res.confirm) {
            console.log(res);
            //复制链接
            wx.setClipboardData({
              data: url,
              success: function (res) {
                wx.getClipboardData({
                  success: function (res) {
                    wx.showToast({
                      title: 'Copy success!'
                    })
                    that.setData({
                      isDownloaded: true,
                      hiddenModalput: true,
                      stuId: ''
                    })
                    that.saveDownRecord()
                  }
                })
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        title: 'Student id error!',
        icon: 'none'
      })
    }
  },

  //保存下载记录
  saveDownRecord: function (e) {
    let that = this;
    ajax.GET({
      ajaxPoint: '/SaveDownRecord',
      params: {
        aid: that.data.userInfo.aid,
        sqtype: 7
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          console.log('下载记录');
        } else {

        }
      }
    })
  },

  // 获取学号
  getStudentId: function (e) {
    let that = this;
    let xh = e.detail.value;
    that.setData({
      stuId: xh
    })
  },

  // 添加图片
  chooseFile: function () {
    let that = this;
    if (that.data.isDownloaded) {
      wx.chooseImage({
        count: 1,  //最多可以选择的图片总数  
        sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
        success: function (res) {
          var tempFilesSize = res.tempFiles[0].size;  //获取图片的大小，单位B
          if (tempFilesSize <= 3000000) { //不能大于3M
            let tempFilePaths = res.tempFilePaths;  //获取图片
            wx.showLoading({
              title: 'loading',
            })
            wx.uploadFile({
              url: config.ajaxUrl + '/savePics.action',
              filePath: tempFilePaths[0],
              name: 'pic',
              formData: {
                pic: tempFilePaths[0]
              },
              header: {
                "Content-Type": "multipart/form-data"
              },
              success: function (resdata) {
                wx.hideLoading();
                let data = JSON.parse(resdata.data)
                if (data.retcode == 0) {
                  that.setData({
                    attachment: data.pic,
                    imagePath: tempFilePaths[0]
                  })
                  console.log(data.pic);
                } else {
                  wx.showToast({
                    icon: 'none',
                    title: 'Request error,please try again'
                  })
                }
              }
            })
          } else {    //图片大于3M
            wx.showToast({
              title: 'Files cannot be larger than 3 MB!',
              icon: 'none'
            })
          }
        }
      })
    } else {
      wx.showModal({
        title: 'Tip',
        content: 'Please download and fill in the form first!',
      })
    }
  },

  //提交申请
  submitApply: function() {
    let that = this;
    // let dormitory = that.data.roomArr[that.data.multiIndex[2]];
    // let dId = dormitory.ssh;
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;

    let atta = that.data.attachment;
    let reason = that.data.note;
    if (reason != '' && atta != '' && sterm !== '') {
      ajax.GET({
        ajaxPoint: '/SaveDorm',
        params: {
          xh: that.data.userInfo.xh,
          sqyy: that.data.note,
          filename: that.data.attachment,
          pxq: sterm
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Successful application',
              confirmText: 'Confirm',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showModal({
              title: 'Error',
              content: res.data.meg,
              cancelText: 'Cancel',
              confirmText: 'Confirm',
              success(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: 'Please complete the information',
      })
    }
    
  },
 
})