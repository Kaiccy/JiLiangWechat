// pages/ManageList/ManageList.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**   
   * 页面的初始数据
   */
  data: {
    itemsList:[],

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getData();
  },

  //请求数据
  getData: function (){
    let that = this;
    ajax.GET({
      ajaxPoint: '/MenuMethods',
      params: {
        
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.retcode == 0) {
          that.setData({
            itemsList: res.data.infolist
          })
        } else {
          wx.showToast({
            title: 'Network error！',
            icon:'none'
          })
        }
      }
    })
  },

  //跳转
  selectThis: function (e){
    let that = this;
    let idx = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '/pages/ManageChildList/ManageChildList?itemsList=' + JSON.stringify(that.data.itemsList[idx].value),
    })
  }
})