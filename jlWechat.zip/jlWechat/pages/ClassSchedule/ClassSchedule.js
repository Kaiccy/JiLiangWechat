// pages/ClassSchedule/ClassSchedule.js

const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    scheduleList:[],
    openSettingBtnHidden:true, //是否显示授权按钮
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.writePhotosAlbum']) {
          wx.authorize({
            scope: 'scope.writePhotosAlbum',
            success() {
              console.log('授权成功');
              that.setData({
                openSettingBtnHidden: true
              })
            },
            fail(res) {
              that.setData({
                openSettingBtnHidden: false
              })
            }
          })
          
        }else{
          that.setData({
            openSettingBtnHidden: true
          })
        }
      }
    })

    this.getScheduleList();
  },

  getScheduleList: function () {
    let userInfo = wx.getStorageSync('userInfo');
    // console.log(userInfo);
    let that = this;
    ajax.GET({
      ajaxPoint: '/getSchoolTimetable',
      params: {
        xh: userInfo.xh,
        ftype: 1
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.retcode == 0) {
          that.setData({
            scheduleList: res.data.infoList
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  showDetail: function(e){
    let that = this;
    let id = e.currentTarget.dataset.id;
    let arr = that.data.scheduleList;
    for(var i = 0; i < arr.length; i ++){
      if(arr[i].id == id){
        console.log(arr[i].cfiles);
        let url = config.imgUrl + 'classCard/' + arr[i].fj;
        console.log(url);       
        if (arr[i].ftype == 1){
          //图片
          wx.previewImage({
            urls: [url],
          })
        }else{
          //文件 先下载后浏览
          console.log(url);
          wx.downloadFile({
            url: url,
            success(res) {
              const filePath = res.tempFilePath
              console.log(filePath);
              wx.openDocument({
                filePath,
                success(res) {
                  console.log('打开文档成功')
                },
                fail(res){
                  wx.showToast({
                    title: 'Open file failed!',
                    icon: 'none'
                  })
                }
              })
            }
          })
        }
      }
    }
  },

  //下载文件
  downloadFiles: function (e) {
    let that = this;
    let fj = e.currentTarget.dataset.fj;
    let ftype = e.currentTarget.dataset.ftype;
    let url = config.imgUrl + 'classCard/' + fj;
    console.log(url);

    //已经授权
    if (ftype == 1) {
      //图片
      if (that.data.openSettingBtnHidden) {
        wx.downloadFile({
          url: url,
          success: function (res) {
            console.log(res);
            //图片保存到本地
            wx.saveImageToPhotosAlbum({
              filePath: res.tempFilePath,
              success: function (data) {
                wx.showToast({
                  title: 'SUCCESS!The photo is already in the album!',
                  icon: 'none',
                  duration: 2000
                })
              },
              fail: function (err) {
                console.log(err);
                wx.showToast({
                  title: err.errMsg,
                  icon: 'none'
                })
              },
              complete(res) {
                console.log(res);
              }
            })
          }
        })
      } else {
        wx.showModal({
          title: 'Tip',
          content: 'Please click the green "To authorize" button for authorization!',
          confirmText: 'ok',
          showCancel: false
        })
      }
      
    } else {
      //文件 
      wx.showModal({
        title: 'Copy the link',
        content: url,
        cancelText: 'Cancel',
        confirmText: 'Copy',
        success(res) {
          if (res.confirm) {
            //复制链接
            wx.setClipboardData({
              data: url,
              success: function (res) {
                wx.getClipboardData({
                  success: function (res) {
                    wx.showToast({
                      title: 'Copy success!'
                    })
                  }
                })
              }
            })
          }
        }
      })
    }
    
  },

  //授权
  handleSetting: function (e) {
    let that = this;
    // 对用户的设置进行判断
    if (!e.detail.authSetting['scope.writePhotosAlbum']) {
      // wx.showModal({
      //   title: '警告',
      //   content: '若不打开授权，则无法将图片保存在相册中！',
      //   showCancel: false
      // })
      that.setData({
        openSettingBtnHidden: false
      })
    } else {
      // wx.showModal({
      //   title: 'Tip',
      //   content: '您已授权，赶紧将图片保存在相册中吧！',
      //   showCancel: false
      // })
      that.setData({
        openSettingBtnHidden: true
      })
    }
  },

})