// pages/applyRecord/applyRecord.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pager: 1,
    pagersize: 10,
    pageTotal: 0,
    recordList: []
  },

  showDetail: function (e){
    wx.navigateTo({
      url: '/pages/applyRecordInfo/applyRecordInfo?id=' + e.currentTarget.dataset.id + '&sqtype=' + e.currentTarget.dataset.sqtype,
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    
    wx.stopPullDownRefresh();
    ajax.GET({
      ajaxPoint: '/getApplicationRecordList',
      params: {
        xh:userInfo.xh,
        pager: 1,
        pagesize: 10
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          that.setData({
            recordList: res.data.infolist,
            pageTotal: res.data.pageTotal
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  getRecordList: function (pager, pagesize) {
    let userInfo = wx.getStorageSync('userInfo');
    let that = this;
    let newArrar = that.data.recordList;
    ajax.GET({
      ajaxPoint: '/getApplicationRecordList',
      params: {
        xh:userInfo.xh,
        pager: pager,
        pagesize: pagesize
      },
      success: function (res) {
        that.setData({
          pager: pager
        })
        if (res.data.retcode == 0) {
          for (var i = 0; i < res.data.infolist.length; i++) {
            newArrar.push(res.data.infolist[i])
          }
          that.setData({
            recordList: newArrar
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },
  onReachBottom: function () {
    let that = this;
    if (that.data.pageTotal > that.data.pager) {
      that.getRecordList(that.data.pager + 1, that.data.pagesize)
    } else {
      wx.showToast({
        title: 'No More',
      })
    }
  },
  onPullDownRefresh: function () {
    this.onLoad()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})