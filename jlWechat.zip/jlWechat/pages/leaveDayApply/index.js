// pages/leaveApply/index.js
const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:[],
    startDate: '2016-09-01',
    leaveDate:'2016-09-02',
    leaveIndex:0,
    leaveType: ['Sick leave','Other reasons'], 
    qjts:'',
    reason:'',
    phoneNum:'',

    attachment: '', //附件图片
    imagePath: '', //临时图片路径

    multiArr: [[], []],
    multiIndex: [0, 0],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });

    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    console.log("当前时间：" + Y + '年' + M + '月' + D + '日');
    that.setData({
      startDate: Y + '-' + M + '-' + D,
      leaveDate: Y + '-' + M + '-' + D,
    });

    // 获取学年学期
    that.getYearList();
  },

  /* 离校原因 */
  bindPickerChange:function(e){
    let that = this;
    that.setData({
      leaveIndex: Number(e.detail.value)
    })
  },
  /* 开始时间 */
  bindDateChange: function (e) {
    let that = this;
    that.setData({
      startDate: e.detail.value
    })
    that.checkDate (that.data.startDate, that.data.leaveDate);
  },

  /* 结束时间 */
  bindDateLeave: function (e) {
    let that = this;
    var start_date = new Date(that.data.startDate.replace(/-/g, "/"));
    var end_date = new Date(e.detail.value.replace(/-/g, "/"));
    //转成毫秒数，两个日期相减
    var time = end_date.getTime() - start_date.getTime();

    if(time < 0){
      wx.showToast({
        title: 'The end date must be greater than the start time',
        icon: 'none'
      })
      return;
    }

    that.setData({
      leaveDate: e.detail.value
    })

    that.checkDate(that.data.startDate, that.data.leaveDate);
  },

 /*计算天数 */
  checkDate: function (startTime, endTime) {
    //日期格式化
    var start_date = new Date(startTime.replace(/-/g, "/"));
    var end_date = new Date(endTime.replace(/-/g, "/"));
    //转成毫秒数，两个日期相减
    var days = end_date.getTime() - start_date.getTime();
    //转换成天数
    var day = parseInt(days / (1000 * 60 * 60 * 24));

    let that = this;
    that.setData({
      qjts: day + 1
    })

    //do something
    console.log("day = ", day);

  },
  /*请假天数 */
  qjts:function(e){
    let that = this;
    that.setData({
      qjts: e.detail.value
    })
  },
  /*原因 */
  reason: function (e) {
    let that = this;
    that.setData({
      reason: e.detail.value
    })
  },
  // 手机号
  getPhoneNum: function (e) {
    let that = this;
    that.setData({
      phoneNum: e.detail.value
    })
  },
  /* 备注 */
  bindNoteChange: function (e) {
    let that = this;
    that.setData({
      note: e.detail.value
    })
  },


  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

  // 附件部分
  // 添加图片
  chooseFile: function () {
    let that = this;
    wx.chooseImage({
      count: 1,  //最多可以选择的图片总数  
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        var tempFilesSize = res.tempFiles[0].size;  //获取图片的大小，单位B
        if (tempFilesSize <= 3000000) { //不能大于3M
          let tempFilePaths = res.tempFilePaths;  //获取图片
          wx.showLoading({
            title: 'loading',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths[0],
            name: 'pic',
            formData: {
              pic: tempFilePaths[0]
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();
              let data = JSON.parse(resdata.data)
              if (data.retcode == 0) {
                that.setData({
                  attachment: data.pic,
                  imagePath: tempFilePaths[0]
                })
                console.log(data.pic);
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        } else {    //图片大于3M
          wx.showToast({
            title: 'Files cannot be larger than 3 MB!',
            icon: 'none'
          })
        }
      }
    })
  },

  /*提交申请 */
  tj:function(e){
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if(that.data.leaveIndex+1 == 1 && that.data.attachment == ''){
      wx.showModal({
        title: 'Tip',
        content: 'Please add the hospital certificate!'
      })
      return;
    }
    if (that.data.leaveIndex + 1 == 2 && that.data.reason == '') {
      wx.showModal({
        title: 'Tip',
        content: 'Please fill in the specific reasons!'
      })
      return;
    }

    var leaveType = 0;
    if (that.data.leaveIndex + 1 == 1){
      leaveType = 2;
    }else{
      leaveType = 1;
    }
    if (that.data.startDate !== '' && that.data.leaveDate !== '' && that.data.qjts !== '' && that.data.leaveIndex !== '' && that.data.phoneNum !== '' && sterm !== ''){
      if (that.data.startDate <= that.data.leaveDate){
        ajax.GET({
          ajaxPoint: '/saveLeave',
          params: {
            xh: userInfo.xh,
            qjlx: leaveType,
            qjks: that.data.startDate,
            qjjs: that.data.leaveDate,
            qjts: that.data.qjts,
            qjsy: that.data.reason,
            filename:that.data.attachment,
            mobile: that.data.phoneNum,
            pxq: sterm
          },
          success: function (res) {
            if (res.data.retcode == 0) {
              wx.showModal({
                title: 'Tips',
                showCancel: false,
                content: 'Successful application',
                confirmText: 'Confirm',
                success: function (res) {
                  if (res.confirm) {
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                }
              })
            } else {
              wx.showToast({
                title: res.data.meg,
                icon: 'none'
              })
            }
          }
        })
      }else{
        wx.showToast({
          title: 'Please fill in the correct date',
          icon: 'none'
        })
      }
    }else{
      wx.showToast({
        title: 'Please improve the application information',
        icon:'none'
      })
    }
  },
  
})