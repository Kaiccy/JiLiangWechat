// pages/repairApply/index.js
const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:[],
    shInfo:[],
    file:'',
    fileUrl:'',
    fileType:'',
    reason:'',


    multiArr: [[], []],
    multiIndex: [0, 0],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });
    ajax.GET({
      ajaxPoint:'/getStudentDorm',
      params:{
        xh: userInfo.xh
      },
      
      success:function(res){
        console.log(res.data);
        if(res.data.retcode==0){
          that.setData({
            shInfo: res.data
          })
        }else{
          wx.showModal({
            title: 'Error',
            content: res.data.meg,
            cancelText:'Cancel',
            confirmText:'Confirm',
            success(res) {
              if (res.confirm) {
                wx.navigateBack({
                  delta: 1
                })
              }
            }
          })
        }
      }
    })

    // 获取学年学期
    that.getYearList();
  },

  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

// 选择附件
  checkFile:function(){
    let that = this;
    wx.showActionSheet({
      itemList: ['upload image', 'upload video'],
      success(res) {
        if (res.tapIndex==0){
          that.chooseFile()
        }else{
          that.chooseVideo()
        }
        that.setData({
          fileType: res.tapIndex
        })
      },
      fail(res) {
        console.log(res.errMsg)
      }
    })
  },
  chooseFile:function(){
    let that = this;
    wx.chooseImage({
      count: 1,  //最多可以选择的图片总数  
      sizeType: ['compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success:function(res){
        var tempFilesSize = res.tempFiles[0].size;  //获取图片的大小，单位B
        if (tempFilesSize <= 3000000) { //不能大于3M
          let tempFilePaths = res.tempFilePaths;  //获取图片
          wx.showLoading({
            title: 'loading',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths[0],
            name: 'pic',
            formData: {
              pic: tempFilePaths[0]
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();
              let data = JSON.parse(resdata.data)
              if (data.retcode == 0) {
                console.log('okkkkk');
                that.setData({
                  file: data.pic,
                  fileUrl: tempFilePaths[0]
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        } else {    //图片大于3M
          wx.showToast({
            title: 'Files cannot be larger than 3 MB!',  
            icon: 'none'      
          })
        }          
      }
    })
  },
  chooseVideo:function(){
    let that = this;
    wx.chooseVideo({
      sourceType: ['album', 'camera'],
      maxDuration: 60,
      camera: 'back',
      success(res) {
        //判断视频大小
        var tempFilesSize = res.size;
        if (tempFilesSize <= 5000000) {   //视频小于或者等于5M时 可以执行获取图片
          let tempFilePaths = res.tempFilePath;
          wx.showLoading({
            title: 'loading...',
          })
          wx.uploadFile({
            url: config.ajaxUrl + '/savePics.action',
            filePath: tempFilePaths,
            name: 'pic',
            formData: {
              pic: tempFilePaths
            },
            header: {
              "Content-Type": "multipart/form-data"
            },
            success: function (resdata) {
              wx.hideLoading();
              let data = JSON.parse(resdata.data);
              if (data.retcode == 0) {
                console.log('okkkkk')
                that.setData({
                  file: data.pic,
                  fileUrl: tempFilePaths
                })
              } else {
                wx.showToast({
                  icon: 'none',
                  title: 'Request error,please try again'
                })
              }
            }
          })
        } else {    //图片大于4M，弹出一个提示框
          wx.showToast({
            title: 'Files cannot be larger than 5 MB!', 
            icon: 'none'       
          })
        }
      }
    })
  },
  // 备注
  getReason:function(e){
    let that = this;
    let value = e.detail.value;
    that.setData({
      reason:value
    })
  },

  //提交
  tj:function(){
    let that = this;
    let reason = that.data.reason;
    let xh = that.data.userInfo.xh;
    let fileType = Number(that.data.fileType) + 1;

    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if (reason !== '' && sterm !== ''){
      if(that.data.fileUrl!==''){
        ajax.GET({
          ajaxPoint:'/SaveRepair',
          params:{
            xh:xh,
            ftype:fileType,
            fname: that.data.file,
            sqyy: reason,
            pxq: sterm
          },
          success:function(res){
            if(res.data.retcode==0){
              wx.showModal({
                title: 'Tips',
                showCancel: false,
                content: 'Success!',
                confirmText: 'Confirm',
                success: function (res) {
                  if (res.confirm) {
                    wx.navigateBack({
                      delta: 1
                    })
                  }
                }
              })
            }else{
              wx.showToast({
                icon: 'none',
                title: 'Submission failed, please resubmit',
              })
            }
          }
        })
      }else{
        wx.showToast({
          icon: 'none',
          title: 'Repair documents cannot be empty',
        })
      }
    }else{
      wx.showToast({
        icon:'none',
        title: 'Repair reasons should not be empty',
      })
    }
  },
  
})