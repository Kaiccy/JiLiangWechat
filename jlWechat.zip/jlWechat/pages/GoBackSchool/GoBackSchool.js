// pages/GoBackSchool/GoBackSchool.js

const app = getApp()
const config = require('../../config.js')
const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    startDate: '', //开始日期
    endDate:'', //截止时间
    returnDate:'', //复学时间
    country:'', //国家
    userInfo: null,
    reason: '',

    multiArr: [[], []],
    multiIndex: [0, 0],
  },

  onLoad: function (options) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    that.setData({
      userInfo: userInfo
    });
    that.initializeDate();

    // 获取学年学期
    that.getYearList();
  },

  //初始化年月日
  initializeDate: function () {
    let that = this;
    var timestamp = Date.parse(new Date());
    var date = new Date(timestamp);
    //获取年份  
    var Y = date.getFullYear();
    //获取月份  
    var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1);
    //获取当日日期 
    var D = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
    console.log("当前时间：" + Y + '年' + M + '月' + D + '日');
    that.setData({
      startDate: Y + '-' + M + '-' + D,
      endDate: Y + '-' + M + '-' + D,
      returnDate: Y + '-' + M + '-' + D
    });
  },

  // 学期学年
  getYearList: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/getXqList',
      params: {

      },
      success: function (res) {
        var mArr = that.data.multiArr;
        let arr = res.data.infolist;
        if (res.data.retcode == 0) {
          var bArr = [];
          for (var i = 0; i < arr.length; i++) {
            bArr.push(arr[i].xns + '-' + arr[i].xne);
          }
          mArr[0] = bArr;
          mArr[1] = ['The first semester', 'The second semester'];

          that.setData({
            multiArr: mArr
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  bindMultiPickerChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      multiIndex: e.detail.value
    })
  },

  bindMultiPickerColumnChange: function (e) {
    let that = this;
    // console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    that.setData({
      col: e.detail.column
    })

  },

  //获取课程
  getCountry: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      country: value
    })
  },

  /* 开始时间 */
  bindStartDateChange: function (e) {
    let that = this;
    that.setData({
      startDate: e.detail.value
    })
  },
  
  /* 截止时间 */
  bindEndDateChange: function (e) {
    let that = this;
    that.setData({
      endDate: e.detail.value
    })
  },

  /* 复学时间 */
  bindReturnDateChange: function (e) {
    let that = this;
    that.setData({
      returnDate: e.detail.value
    })
  },

  //获取原因
  getReason: function (e) {
    let that = this;
    let value = e.detail.value;
    that.setData({
      reason: value
    })
  },

  //提交
  submit: function () {
    let that = this;
    let startDate = that.data.startDate;
    let endDate = that.data.endDate;
    let returnDate = that.data.returnDate;
    let country = that.data.country;
    let reason = that.data.reason;
    let idx = that.data.multiIndex[1] + 1;
    let sterm = that.data.multiArr[0][that.data.multiIndex[0]] + '-' + idx;
    if (startDate != '' && endDate != '' && returnDate != '' && country != '' && reason != '' && sterm != '') {
      ajax.GET({
        ajaxPoint: '/saveResuming',
        params: {
          aid: that.data.userInfo.aid,
          name: that.data.userInfo.xm,
          gj: country,
          xxsjStart: startDate,
          xxsjEnd: endDate,
          fxsj: returnDate,
          sqyy: reason,
          pxq: sterm
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showModal({
              title: 'Tips',
              showCancel: false,
              content: 'Success!',
              confirmText: 'Confirm',
              success: function (res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          } else {
            wx.showModal({
              title: 'Error',
              content: res.data.meg,
              cancelText: 'Cancel',
              confirmText: 'Confirm',
              success(res) {
                if (res.confirm) {
                  wx.navigateBack({
                    delta: 1
                  })
                }
              }
            })
          }
        }
      })
    } else {
      wx.showToast({
        icon: 'none',
        title: 'Please complete the information',
      })
    }
  }

})