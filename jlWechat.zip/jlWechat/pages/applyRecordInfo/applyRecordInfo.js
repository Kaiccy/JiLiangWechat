// pages/applyRecordInfo/applyRecordInfo.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    recordInfo:{},
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    let recordId = options.id;
    let sqtype = options.sqtype;
    console.log(recordId);
    console.log(sqtype);
    ajax.GET({
      ajaxPoint: '/getApplicationRecordInfo',
      params: {
        id: recordId,
        sqtype: sqtype
      },
      success: function (res) {
        console.log(res.data);
        if (res.data.retcode == 0) {
          that.setData({
            recordInfo: res.data
          })
        }
      }
    })
  },

})