// pages/ManageInfo/ManageInfo.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    info:{},
    infoId:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      infoId: JSON.parse(options.infoId)
    })
    this.getData();
  },

  //请求数据
  getData: function () {
    let that = this;
    ajax.GET({
      ajaxPoint: '/loadMethod',
      params: {
        id: that.data.infoId
      },
      success: function (res) {
        let font = res.data.content.replace(/<[^>]+>/g, '');
        if (res.data.retcode == 0) {
          // 解析标签
          let content = res.data.content.replace(/<[^>]+>/g, '');
          res.data.content = content;
          that.setData({
            info: res.data
          })
          console.log(that.data.info);
        } else {
          wx.showToast({
            title: 'Network error！',
            icon: 'none'
          })
        }
      }
    })
  },

  // 显示详情
  viewFiles: function (e) {
    let that = this;
    let userInfo = wx.getStorageSync('userInfo');
    let url = config.imgUrl + that.data.info.mfile;
    console.log(url);
    if (that.data.info.cftype == 1) {
      //图片
      wx.previewImage({
        urls: [url]
      })
    } else {
      //文件
      wx.downloadFile({
        url: url,
        success(res) {
          const filePath = res.tempFilePath
          wx.openDocument({
            filePath,
            success(res) {
              console.log('打开文档成功')
            },
            fail(res) {
              wx.showToast({
                title: 'Open file failed!',
                icon: 'none'
              })
            }
          })
        }
      })
    }
  },

})