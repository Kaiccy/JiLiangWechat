// pages/News/News.js

const app = getApp()
const ajax = require('../../utils/request.js')
const WxParse = require('../../wxParse/wxParse.js');
const config = require('../../config.js');
var time = require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    pager: 0,
    pagesize: 10,
    pageTotal: 0,//总条数
    newsList: [],
    picAddress: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that = this;
    that.setData({
      picAddress: config.imgUrl + 'news/'
    })
    let userInfo = wx.getStorageSync('userInfo');
    if (userInfo.aid && userInfo.aid !== '') {

    } else {
      wx.redirectTo({
        url: '/pages/login/login',
      })
    };
    wx.stopPullDownRefresh();
    ajax.GET({
      ajaxPoint: '/getWXNews',
      params: {
        type:'news',
        offset: 0,
        count: 10
      },
      success: function (res) {
        if (res.data.retcode == 0) {
          console.log(res.data);
          for (var i = 0; i < res.data.item.length; i++) {
            // res.data.infolist[i].content = WxParse.wxParse('article', 'html', res.data.infolist[i].content, that, 5);
            // if (res.data.infolist[i].pics !== ('' || null)) {
            //   res.data.infolist[i].pics = res.data.infolist[i].pics.split(',');
            // }
            //设置时间
            res.data.item[i].content.update_time = time.formatTime(res.data.item[i].content.update_time, 'Y-M-D h:m:s');
          }
          that.setData({
            newsList: res.data.item,
            pageTotal: res.data.total_count
          })
        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

// 获取新闻列表
  getNewsList: function (pager, pagesize) {
    let that = this;
    let newArrar = that.data.newsList;
    console.log(pager,pagesize);
    ajax.GET({
      ajaxPoint: '/getWXNews',
      params: {
        type: 'news',
        offset: pager,
        count: pagesize
      },
      success: function (res) {
        that.setData({
          pager: pager
        })
        if (res.data.retcode == 0) {
          console.log(res.data);
          for (var i = 0; i < res.data.item.length; i++) {
            res.data.item[i].content.update_time = time.formatTime(res.data.item[i].content.update_time, 'Y-M-D h:m:s');
            newArrar.push(res.data.item[i])
          }
          that.setData({
            newsList: newArrar,
            pageTotal: res.data.total_count
          })

        } else {
          wx.showToast({
            title: res.data.meg,
            icon: 'none'
          })
        }
      }
    })
  },

  onReachBottom: function () {
    let that = this;
    console.log(that.data.newsList.length);
    if (that.data.pageTotal > that.data.newsList.length) {
      that.getNewsList(that.data.pager + 10, that.data.pagesize)
    } else {
      wx.showToast({
        title: 'No More',
      })
    }
  },
  onPullDownRefresh: function () {
    let that = this;
    that.setData({
      pager:0
    })
    that.onLoad()
  },
  /*查看新闻详情 */
  viewDetail: function (e) {
    let jsonParam = {
      url: e.currentTarget.dataset.url
    }
    wx.navigateTo({
      url: '/pages/ConfirmWebview/ConfirmWebview?jsonParam=' + encodeURIComponent(JSON.stringify(jsonParam)) + '&type=3',
    })
  }

})