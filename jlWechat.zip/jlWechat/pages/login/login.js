//index.js
//获取应用实例
const app = getApp()
const ajax = require('../../utils/request.js')

Page({
  data: {
    loginname:'',
    password:''
  },
  onLoad: function () {

  },
  getLoginName: function (e) {
    let that = this;
    that.setData({
      loginname: e.detail.value
    })
  },
  getPassword: function (e) {
    let that = this;
    that.setData({
      password: e.detail.value
    })
  },
  toLogin: function (e) {
    let that = this;
    if(that.data.loginname==''){
      wx.showToast({
        icon: 'none',
        title: 'The account number cannot be empty',
      })
    } else if (that.data.password == ''){
      wx.showToast({
        icon: 'none',
        title: 'The password cannot be empty',
      })
    }else{

      //获取code
      var code = '';
      wx.login({ // 登录获取code
        success: res => {
          code = res.code;
          console.log('code= ' + code);
          ajax.GET({
            ajaxPoint: '/login',
            params: {
              loginname: that.data.loginname,
              loginpwd: that.data.password,
              js_code: code
            },
            success: function (res) {
              if (res.data.retcode == 0) {
                wx.setStorage({
                  key: 'userInfo',
                  data: res.data
                });
                console.log(res.data);

                wx.reLaunch({
                  url: '/pages/index/index',
                })
              } else {
                wx.showToast({
                  title: res.data.meg,
                  icon: 'none'
                })
              }
            }
          })
        },
        fail: function () {
          wx.hideLoading();
          wx.showToast({
            title: '登录出错,请检查网络',
            icon: 'none',
            mask: true
          })
        }
      })      
    }
  },


})
