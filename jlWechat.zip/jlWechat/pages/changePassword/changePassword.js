// pages/changePassword/changePassword.js

const ajax = require('../../utils/request.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    originalPassword:'',
    newPassword:'',
    confirmPassword:''
  },

  // 
  doneAction: function(){
    console.log("提交");
    let that = this;

    console.log(that.data.originalPassword);
    console.log(that.data.newPassword);
    console.log(that.data.confirmPassword);

    if (that.data.originalPassword == '') {
      wx.showToast({
        icon: 'none',
        title: 'The original password cannot be empty',
      })
    } else if (that.data.newPassword == '') {
      wx.showToast({
        icon: 'none',
        title: 'The new password cannot be empty',
      })
    } else if (that.data.confirmPassword == '') {
      wx.showToast({
        icon: 'none',
        title: 'The confirm password cannot be empty',
      })
    } else{
      let userInfo = wx.getStorageSync('userInfo');
      ajax.GET({
        ajaxPoint: '/updatePwd',
        params: {
          loginname: userInfo.loginname,
          originalPwd: that.data.originalPassword,
          newPwd: that.data.newPassword,
          confirmPwd:that.data.confirmPassword
        },
        success: function (res) {
          if (res.data.retcode == 0) {
            wx.showToast({
              title: 'success!',
              icon: 'none'
            })
          } else {
            wx.showToast({
              title: res.data.meg,
              icon: 'none'
            })
          }
        }
      })
    }   
  },

  getOriginalPassword: function (e){
    let that = this;
    that.setData({
      originalPassword: e.detail.value
    })
  },

  getNewPassword: function(e){
    let that = this;
    that.setData({
      newPassword: e.detail.value
    })
  },

  getConfirmPassword: function(e){
    let that = this;
    that.setData({
      confirmPassword: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})